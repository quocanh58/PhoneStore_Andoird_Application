<?php

include 'dbhelper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postdata = file_get_contents("php://input");
    $request = json_decode($postdata);
 
    if (isset($request->type)) {
        $type = $request->type;
       
        if ($type === "insert") {
            if (isset($request->tenloaisanpham) && isset($request->hinhanhloaisanpham)) {
                $tenloaisanpham = $request->tenloaisanpham;
                $hinhanhloaisanpham = $request->hinhanhloaisanpham;
                $sql = "INSERT INTO `loaisanpham`(`tenloaisanpham`, `hinhanhloaisanpham`) VALUES ('$tenloaisanpham','$hinhanhloaisanpham')";
                
                if (execute($sql)) {
                    $response = array(
                        "result" => 1,
                        "message" => "Thêm loại sản phẩm thành công",
                    );
                    // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                } else {
                    $response = array(
                        "result" => 1,
                        "message" => "Thêm loại sản phẩm thất bại",
                    );
                    // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                }
            }
        }
        else if ($type === "update") {
            if (isset($request->id) && isset($request->tenloaisanpham) && isset($request->hinhanhloaisanpham)) {
                $id = $request->id;
                $tenloaisanpham = $request->tenloaisanpham;
                $hinhanhloaisanpham = $request->hinhanhloaisanpham;
                $sql = "UPDATE `loaisanpham` SET `tenloaisanpham`='$tenloaisanpham', `hinhanhloaisanpham`='$hinhanhloaisanpham' WHERE `id`=$id";
                //echo $sql;
                if (execute($sql)) {
                    $response = array(
                        "result" => 1,
                        "message" => "Cập nhật loại sản phẩm thành công",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                } else {
                    $response = array(
                        "result" => 0,
                        "message" => "Cập nhật loại sản phẩm thất bại",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                }
            }
        }
        else if ($type === "delete") {
            if (isset($request->id)) {
                $id = $request->id;
                $sql = "DELETE FROM `loaisanpham` WHERE `id`=$id";
                if (execute($sql)) {
                    $response = array(
                        "result" => 1,
                        "message" => "Xóa loại sản phẩm thành công",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                } else {
                    $response = array(
                        "result" => 0,
                        "message" => "Xóa loại sản phẩm thất bại",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                }
            }
        }
        
        
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['getAllSanPham'])) {
        $sql = 'SELECT * FROM `loaisanpham` WHERE 1';
        $db = executeResult($sql);
        if ($db) {
            // Tạo mảng dữ liệu JSON với trường "result" bằng 1 và dữ liệu kết quả
            $response = array(
                "result" => 1,
                "message" => "Lấy dữ liệu thành công",
                "data" => $db
            );
            
            // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
        } else {
            // Nếu không có dữ liệu, trả về "result" bằng 0 hoặc thông báo lỗi khác
            $response = array(
                "result" => 0,
                "message" => "Lấy dữ liệu thất bại",
                "data" => []
            );
            echo json_encode($response);
        }
    }
}
?>
