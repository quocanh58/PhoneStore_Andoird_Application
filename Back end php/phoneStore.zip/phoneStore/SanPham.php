<?php

include 'dbhelper.php';



function getAllSanPham() {
    $sql = 'SELECT * FROM `sanpham` WHERE 1';
    $sanpham = executeResult($sql);
    return $sanpham;
}


function insertSanPham($tensanpham, $giasanpham, $hinhanhsanpham, $mota, $idsanpham) {
    // Thực hiện câu lệnh INSERT, không cần thêm `Id` vào câu lệnh vì nó tự động tăng (AUTO_INCREMENT)
    $sql = "INSERT INTO `sanpham` (`tensanpham`, `giasanpham`, `hinhanhsanpham`, `mota`, `idloaisanpham`)
            VALUES ('$tensanpham', $giasanpham, '$hinhanhsanpham', '$mota', $idsanpham)";
            
    return execute($sql);
}


function updateSanPham($id, $tensanpham, $giasanpham, $hinhanhsanpham, $mota, $idsanpham) {
    // Thực hiện câu lệnh UPDATE dựa trên `Id`
    $sql = "UPDATE `sanpham` 
            SET `tensanpham`='$tensanpham', `giasanpham`=$giasanpham,
                `hinhanhsanpham`='$hinhanhsanpham', `mota`='$mota', `idloaisanpham`=$idsanpham
            WHERE `Id` = $id";
    return execute($sql);
}


function deleteSanPham($id) {
    // Thực hiện câu lệnh DELETE dựa trên `Id`
    $sql = "DELETE FROM `sanpham` WHERE `Id` = $id";
    return execute($sql);
}


function getSanPhamByIdLoaiSanPham($idloaisanpham) {
    global $conn;
    $sql = "SELECT * FROM `sanpham` WHERE `idloaisanpham` = $idloaisanpham";
    return executeResult($sql);
}




if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postdata = file_get_contents("php://input");
    $request = json_decode($postdata);
     
    if (isset($request->type)) {
        $type = $request->type;
        if ($type === "insert") {
            if (isset($request->tensanpham) && isset($request->giasanpham)
                && isset($request->hinhanhsanpham) && isset($request->mota) && isset($request->idsanpham)) {
                $tensanpham = $request->tensanpham;
                $giasanpham = $request->giasanpham;
                $hinhanhsanpham = $request->hinhanhsanpham;
                $mota = $request->mota;
                $idsanpham = $request->idsanpham;
                
                if (insertSanPham($tensanpham, $giasanpham, $hinhanhsanpham, $mota, $idsanpham)) {
                    $response = array(
                        "result" => 1,
                        "message" => "Thêm sản phẩm thành công",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                } else {
                    $response = array(
                        "result" => 0,
                        "message" => "Thêm sản phẩm thất bại",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                }
            }
        }
        else if ($type === "update") {
            if (isset($request->Id) && isset($request->tensanpham) && isset($request->giasanpham)
                && isset($request->hinhanhsanpham) && isset($request->mota) && isset($request->idsanpham)) {
                $id = $request->Id;
                $tensanpham = $request->tensanpham;
                $giasanpham = $request->giasanpham;
                $hinhanhsanpham = $request->hinhanhsanpham;
                $mota = $request->mota;
                $idsanpham = $request->idsanpham;
                
                if (updateSanPham($id, $tensanpham, $giasanpham, $hinhanhsanpham, $mota, $idsanpham)) {
                    $response = array(
                        "result" => 1,
                        "message" => "Cập nhật sản phẩm thành công",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                } else {
                    $response = array(
                        "result" => 0,
                        "message" => "Cập nhật sản phẩm thất bại",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                }
            }
        }
        else  if ($type === "delete") {
            if (isset($request->Id)) {
                $id = $request->Id;
                
                if (deleteSanPham($id)) {
                    $response = array(
                        "result" => 1,
                        "message" => "Xóa sản phẩm thành công",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                } else {
                    $response = array(
                        "result" => 0,
                        "message" => "Xóa sản phẩm thất bại",
                    );
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                }
            }
        }
    }
}

else if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['getAllSanPham'])) {
        $sanpham = getAllSanPham();
        if ($sanpham) {
            // Tạo mảng dữ liệu JSON với trường "result" bằng 1 và dữ liệu kết quả
            $response = array(
                "result" => 1,
                "message" => "Lấy dữ liệu sản phẩm thành công",
                "data" => $sanpham
            );

            // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
            return;
        } else {
            // Nếu không có dữ liệu, trả về "result" bằng 0 hoặc thông báo lỗi khác
            $response = array(
                "result" => 0,
                "message" => "Lấy dữ liệu sản phẩm thất bại",
                "data" => []
            );
            echo json_encode($response);
            
            return;
        }
    }
    
    if (isset($_GET['getSanPhamByIdLoaiSanPham'])) {
    $idloaisanpham = $_GET['idloaisanpham'];

    $sanpham = getSanPhamByIdLoaiSanPham($idloaisanpham);

    if ($sanpham) {
        $response = array(
            "result" => 1,
            "message" => "Lấy sản phẩm theo loại sản phẩm thành công",
            "data" => $sanpham
        );
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    } else {
        $response = array(
            "result" => 0,
            "message" => "Không tìm thấy sản phẩm theo loại sản phẩm",
            "data" => []
        );
        echo json_encode($response);
    }
}

}
?>
