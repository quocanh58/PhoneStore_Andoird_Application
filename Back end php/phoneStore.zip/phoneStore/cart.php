<?php
include 'dbhelper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postdata = file_get_contents("php://input");
    $request = json_decode($postdata);
    if (isset($request->type)) {
        $type = $request->type;
        if ($type === "insert") {
            if (isset($request->productID) && isset($request->quantity) && isset($request->userID)) {
                $productID = $request->productID;
                $quantity = $request->quantity;
                $userID = $request->userID;
                 // Lấy thông tin số lượng tồn của sản phẩm
                    $productInfo = executeSingleResult("SELECT soluong FROM sanpham WHERE Id = $productID");
                    $availableQuantity = isset($productInfo['soluong']) ? $productInfo['soluong'] : 0;
                 
                
                // Kiểm tra xem sản phẩm đã có trong giỏ hàng chưa
                $existingCartItem = executeSingleResult("SELECT * FROM cart WHERE productID = $productID AND userID = $userID");
                $sql =  "INSERT INTO `cart`(`productID`, `quantity`,`userID`) VALUES ($productID, $quantity, $userID)";
                if ($existingCartItem) {
                    
                    if ($existingCartItem['quantity']  + $quantity > $availableQuantity) {
                     $response = array(
                        "result" => 0,
                        "message" => "Không đủ số lượng tồn kho",
                        "data" => []
                    );
                    // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                     
                 }
                    // Nếu sản phẩm đã có trong giỏ hàng, cập nhật số lượng
                    $newQuantity = $existingCartItem['quantity'] + $quantity;
                    $sql = "UPDATE cart SET quantity = $newQuantity WHERE id = {$existingCartItem['id']}";
                } 
                
                
                if ( $quantity + 1 > $availableQuantity) {
                     $response = array(
                        "result" => 0,
                        "message" => "Không đủ số lượng tồn kho",
                        "data" => []
                    );
                    // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                     
                 }

                if (execute($sql)) {
                    $sql = "SELECT cart.*, sanpham.* FROM cart INNER JOIN sanpham ON cart.productID = sanpham.id WHERE cart.userID = $userID";
                    $data = executeResult($sql);
                    $cartData = array();
                    if ($data) {
                        foreach ($data as $row) {
                            $productInfo = array(
                                "Id" => $row['productID'],
                                "tensanpham" => $row['tensanpham'],
                                "giasanpham" => $row['giasanpham'],
                                "hinhanhsanpham" => $row['hinhanhsanpham'],
                                "mota" => $row['mota'],
                                "soluong" => $row['soluong'],
                                "idloaisanpham" => $row['idloaisanpham'],
                            );

                            $cartItem = array(
                                "id" => $row['id'],
                                "quantity" => $row['quantity'],
                                "userID" => $row['userID'],
                                "product" => $productInfo,
                            );
                            array_push($cartData, $cartItem);
                        }
                    }
                    $response = array(
                        "result" => 1,
                        "message" => "Thêm vào giỏ hàng thành công",
                        "data" => $cartData
                    );
                    // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                } else {
                    $response = array(
                        "result" => 1,
                        "message" => "Thêm vào giỏ hàng thất bại",
                        "data" => []
                    );
                    // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
                    echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    return;
                }
            }
        } else 
            if ($type === "update") {
                if (isset($request->cartID) && isset($request->quantity)) {
                    $cartID = $request->cartID;
                    $quantity = $request->quantity;
                    $userID = $request->userID;

                    $productSQL = "SELECT `soluong` FROM `sanpham` WHERE `id` IN (SELECT `productID` FROM `cart` WHERE `id` = $cartID)";
                    $productQuantity = executeSingleResult($productSQL);
                    // Câu lệnh SQL để cập nhật số lượng sản phẩm trong giỏ hàng dựa trên cartID
                    $sql = "UPDATE `cart` SET `quantity` = $quantity WHERE `id` = $cartID";
                    if ($productQuantity && $productQuantity['soluong'] >= $quantity) {
                        if (execute($sql)) {
                            // Câu lệnh SQL để lấy thông tin giỏ hàng sau khi cập nhật
                            $sql = "SELECT cart.*, sanpham.* FROM cart INNER JOIN sanpham ON cart.productID = sanpham.id WHERE cart.userID = $userID";
                           
                            $data = executeResult($sql);
                            $cartData = array();
                            if ($data) {
                                foreach ($data as $row) {
                                    $productInfo = array(
                                        "Id" => $row['productID'],
                                        "tensanpham" => $row['tensanpham'],
                                        "giasanpham" => $row['giasanpham'],
                                        "hinhanhsanpham" => $row['hinhanhsanpham'],
                                        "mota" => $row['mota'],
                                        "soluong" => $row['soluong'],
                                        "idloaisanpham" => $row['idloaisanpham'],
                                    );
    
                                    $cartItem = array(
                                        "id" => $row['id'],
                                        "quantity" => $row['quantity'],
                                        "userID" => $row['userID'],
                                        "product" => $productInfo,
                                    );
                                    array_push($cartData, $cartItem);
                                }
                            }
                            $response = array(
                                "result" => 1,
                                "message" => "Sửa giỏ hàng thành công",
                                "data" => $cartData
                            );
                            // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
                            echo json_encode($response, JSON_UNESCAPED_UNICODE);
                            return;
                        }
                    }
                    else{
                        $response = array(
                            "result" => 0,
                            "message" => "Số lượng sản phẩm không đủ cho cập nhật",
                            "data" => array()
                        );
                        echo json_encode($response, JSON_UNESCAPED_UNICODE);
                    }
                }
            }
         else 
            if ($type === "delete") {
                if (isset($request->cartID)) {
                    $userID = $request->userID;
                    $cartID = $request->cartID;
                    // Câu lệnh SQL để xóa sản phẩm khỏi giỏ hàng dựa trên cartID
                    $sql = "DELETE FROM `cart` WHERE `id` = $cartID";
                    if (execute($sql)) {
                       
                        // Câu lệnh SQL để lấy thông tin giỏ hàng sau khi xóa
                        $sql = "SELECT cart.*, sanpham.* FROM cart INNER JOIN sanpham ON cart.productID = sanpham.id WHERE cart.userID = $userID";
                        
                        $data = executeResult($sql);
                       
                        $cartData = array();
                        if ($data) { 
                            foreach ($data as $row) {
                                $productInfo = array(
                                    "Id" => $row['productID'],
                                    "tensanpham" => $row['tensanpham'],
                                    "giasanpham" => $row['giasanpham'],
                                    "hinhanhsanpham" => $row['hinhanhsanpham'],
                                    "mota" => $row['mota'],
                                    "soluong" => $row['soluong'],
                                    "idloaisanpham" => $row['idloaisanpham'],
                                );

                                $cartItem = array(
                                    "id" => $row['id'],
                                    "quantity" => $row['quantity'],
                                    "userID" => $row['userID'],
                                    "product" => $productInfo,
                                );
                                array_push($cartData, $cartItem);
                            }
                        }
                        $response = array(
                            "result" => 1,
                            "message" => "Xoá giỏ hàng thành công",
                            "data" => $cartData
                        );
                        echo json_encode($response, JSON_UNESCAPED_UNICODE);
                        return;
                    } else {
                        $response = array(
                            "result" => 0,
                            "message" => "Xóa sản phẩm khỏi giỏ hàng thất bại",
                            "data" => []
                        );
                        // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
                        echo json_encode($response, JSON_UNESCAPED_UNICODE);
                        return;
                    }
                }
            }
        
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['getUserCart'])) {
        if (isset($_GET['userID'])) {
            $userID = $_GET['userID'];

            // Câu lệnh SQL để lấy giỏ hàng của người dùng dựa trên userID
            $sql = "SELECT cart.*, sanpham.* FROM cart INNER JOIN sanpham ON cart.productID = sanpham.id WHERE cart.userID = $userID";
            $data = executeResult($sql);
            if ($data) {
                $cartData = array();

                foreach ($data as $row) {
                    $productInfo = array(
                        "Id" => $row['productID'],
                        "tensanpham" => $row['tensanpham'],
                        "giasanpham" => $row['giasanpham'],
                        "hinhanhsanpham" => $row['hinhanhsanpham'],
                        "mota" => $row['mota'],
                        "soluong" => $row['soluong'],
                        "idloaisanpham" => $row['idloaisanpham'],
                    );

                    $cartItem = array(
                        "id" => $row['id'],
                        "quantity" => $row['quantity'],
                        "userID" => $row['userID'],
                        "product" => $productInfo,
                    );

                    array_push($cartData, $cartItem);
                }

                $response = array(
                    "result" => 1,
                    "message" => "Lấy giỏ hàng của người dùng thành công",
                    "data" => $cartData
                );

                // In ra dữ liệu JSON với JSON_UNESCAPED_UNICODE
                echo json_encode($response, JSON_UNESCAPED_UNICODE);
            } else {
                // Nếu không có dữ liệu, trả về "result" bằng 0 hoặc thông báo lỗi khác
                $response = array(
                    "result" => 0,
                    "message" => "Không tìm thấy giỏ hàng cho người dùng",
                    "data" => []
                );
                echo json_encode($response);
            }
        } else {
            $response = array(
                "result" => 0,
                "message" => "Thiếu thông tin người dùng (userID)",
                "data" => []
            );
            echo json_encode($response);
        }
    }
}