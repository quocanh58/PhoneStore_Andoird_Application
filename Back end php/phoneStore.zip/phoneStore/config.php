<?php
define('HOST', 'localhost');
define('USERNAME', 'nrobluef_phonestore');
define('PASSWORD', 'Ngocnhu1002@');
define('DATABASE', 'nrobluef_phoneStore');
?>

