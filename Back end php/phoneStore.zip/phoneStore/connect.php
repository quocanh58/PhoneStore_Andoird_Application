<?php
include 'dbhelper.php';

$sql = "SELECT * FROM `loaisanpham` WHERE 1";
$db = executeResult($sql);

if ($db) {
    echo "Connect successfully.";
} else
    echo "Connect failed.";
?>
