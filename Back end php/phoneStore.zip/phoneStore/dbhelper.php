<?php
require_once('config.php');

function execute($sql)
{
    // open connection to database

    $con = mysqli_connect(HOST, USERNAME, PASSWORD, DATABASE);
    mysqli_set_charset($con, "utf8");
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // insert, update, delete
    $result = mysqli_query($con, $sql);

    // check if the query was successful
    if ($result === true) {
        //close connection
        mysqli_close($con);
        return true;
    } else {
        //close connection
        mysqli_close($con);
        return false;
    }
}

function executeResult($sql)
{
	//save data into table
	// open connection to database

	$con = mysqli_connect(HOST, USERNAME, PASSWORD, DATABASE);
	mysqli_set_charset($con, "utf8");
	//insert, update, delete
	$result = mysqli_query($con, $sql);
	$data   = [];
	if ($con->error) {
		die("Connection failed: " . mysqli_error($con));
	}
	if ($result != null) {
		while ($row = mysqli_fetch_array($result, 1)) {
			$data[] = $row;
		}
	}

	//close connection
	mysqli_close($con);

	return $data;
}

function executeSingleResult($sql)
{
	//save data into table
	// open connection to database

	$con = mysqli_connect(HOST, USERNAME, PASSWORD, DATABASE);
	mysqli_set_charset($con, "utf8");
	//insert, update, delet
	$result = mysqli_query($con, $sql);
	$row    = null;
	if ($result != null) {
		$row = mysqli_fetch_array($result, 1);
	}
	//close connection
	mysqli_close($con);

	return $row;
}