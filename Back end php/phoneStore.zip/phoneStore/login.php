<?php
include 'dbhelper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postdata = file_get_contents("php://input");
    $request = json_decode($postdata);
    if (isset($request->email) && isset($request->password)) {
    
        $email = $request->email;
        $password = $request->password;

        $sql = "SELECT * FROM `user` WHERE `email` = '$email'";
        $user = executeSingleResult($sql);
        
        if ($user && password_verify($password, $user['password'])) {
            $response = array(
                "result" => 1,
                "message" => "Đăng nhập thành công",
                "user" => $user
            );
            echo json_encode($response);
        } else {
            $response = array(
                "result" => 0,
                "message" => "Đăng nhập thất bại",
                 "user" => null
            );
            echo json_encode($response);
        }
    }
}
?>
