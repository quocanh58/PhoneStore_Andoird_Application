<?php
include 'dbhelper.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Giải mã dữ liệu JSON được gửi từ ứng dụng
    $data = json_decode(file_get_contents('php://input'), true);
    $conn = mysqli_connect("localhost", "nrobluef_phonestore", "Ngocnhu1002@", "nrobluef_phoneStore");
    mysqli_set_charset($conn, "utf8");
    if (empty($data)) {
        die("Dữ liệu JSON không hợp lệ");
    }
    if ($data['type'] == "insert") {
        // Kết nối đến cơ sở dữ liệu MySQL

        if (!$conn) {
            die("Không thể kết nối đến cơ sở dữ liệu: " . mysqli_connect_error());
        }
        // Lấy thông tin từ JSON
        $userID = $data['UserID'];
        $totalPrice = $data['totalPrice'];
        $orderTime = date('Y-m-d H:i:s', floor($data['time'] / 1000)); // Chuyển đổi timestamp thành định dạng datetime
        // Tạo đơn hàng mới
        $insertOrderSQL = "INSERT INTO donhang (idkhachhang, ngaydat, tongtien, userId)
                  VALUES (NULL, '$orderTime', $totalPrice, $userID)";
        if (mysqli_query($conn, $insertOrderSQL)) {
            $orderId = mysqli_insert_id($conn);
            // Thêm chi tiết đơn hàng
            foreach ($data['data'] as $item) {
                $idsanpham = $item['idsanpham'];
                $soluong = $item['soluong'];
                $dongia = $item['dongia'];
                // Cập nhật số lượng sản phẩm trong bảng 'sanpham'
                $updateQuantitySQL = "UPDATE sanpham SET soluong = soluong - $soluong WHERE Id = $idsanpham";

                if (mysqli_query($conn, $updateQuantitySQL)) {
                    // Số lượng sản phẩm đã được cập nhật

                    // Tiếp tục thêm chi tiết đơn hàng vào bảng 'chitietdonhang'
                    $insertDetailSQL = "INSERT INTO chitietdonhang (iddonhang, idsanpham, soluong, dongia)
                                VALUES ($orderId, $idsanpham, $soluong, $dongia)";
                    mysqli_query($conn, $insertDetailSQL);
                }
            }
            // Trả về kết quả thành công
            $response = array(
                "result" => 1,
                "message" => "Đặt hàng thành công"
            );
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
        } else {
            // Trả về thông báo lỗi nếu có lỗi khi tạo đơn hàng
            $response = array(
                "result" => 0,
                "message" => "Đặt hàng thất bại"
            );
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
        }
    } 

  if ($data['type'] == "delete") {
        $orderId = $data['orderId'];
        $userId = $data['UserID'];
    
        $sqlDelete = "UPDATE donhang SET status = 'Đã huỷ' WHERE id = $orderId";
  if (mysqli_query($conn, $sqlDelete)) {
            
            
        // Tạo mảng chứa thông tin đơn hàng đã đặt
        $donhangArray = array();
    
        // Lấy danh sách đơn hàng đã đặt
        $selectOrdersSQL = "SELECT * FROM donhang where userId = $userId ";
        $result = executeResult($selectOrdersSQL);
        foreach($result as $row){
            $orderID = $row['Id'];
              
            // Lấy chi tiết đơn hàng
            $selectChiTietSQL = "SELECT * FROM chitietdonhang WHERE iddonhang = $orderID";
            $resultChiTiet = executeResult($selectChiTietSQL);
            $chitietArray = array();
            foreach($resultChiTiet as $rowChiTiet){
                // Thêm chi tiết đơn hàng vào mảng
                $idsanpham = $rowChiTiet['idsanpham'];
                $sqlSanPham = "select * from sanpham where Id = $idsanpham";
    
                $sanpham = executeSingleResult($sqlSanPham);
                $rowChiTiet['sanpham'] = $sanpham;
                $chitietArray[] = $rowChiTiet;
            }
            
          
            
            // if (mysqli_num_rows($resultChiTiet) > 0) {
            //     while ($rowChiTiet = mysqli_fetch_assoc($resultChiTiet)) {
                  
            //         // Thêm chi tiết đơn hàng vào mảng
            //         $idsanpham = $rowChiTiet['idsanpham'];
            //         $sqlSanPham = "select * from sanpham where Id = $idsanpham";
        
            //         $sanpham = executeSingleResult($sqlSanPham);
            //         $rowChiTiet['sanpham'] = $sanpham;
            //         $chitietArray[] = $rowChiTiet;
            //     }
            // }
          
            // Thêm thông tin đơn hàng và chi tiết vào mảng đơn hàng
            $row['chitiet'] = $chitietArray;
           
            $donhang = array(
                "donhang" => $row,
            );
            $donhangArray[] = $donhang;
        }
            // Trả về danh sách đơn hàng đã đặt và chi tiết các đơn hàng đó
            $response = array(
                "result" => 1,
                "message" => "Huỷ đơn đặt hàng thành công",
                "data" => $donhangArray
            );
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
        } else {
            $response = array(
                "result" => 0,
                "message" => "Huỷ đơn đặt hàng thất bại"
            );
            echo json_encode($response, JSON_UNESCAPED_UNICODE);
        }
    }

    // Đóng kết nối đến cơ sở dữ liệu
    mysqli_close($conn);
}


if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if(isset($_GET['getAllOrder']) && isset($_GET['userID'])){
        $userId = $_GET['userID'];
        // Tạo mảng chứa thông tin đơn hàng đã đặt
        $donhangArray = array();
    
        // Lấy danh sách đơn hàng đã đặt
       $selectOrdersSQL = "SELECT * FROM donhang WHERE userId = $userId ORDER BY Id DESC";

        $result = executeResult($selectOrdersSQL);
        foreach($result as $row){
            $orderID = $row['Id'];
              
            // Lấy chi tiết đơn hàng
            $selectChiTietSQL = "SELECT * FROM chitietdonhang WHERE iddonhang = $orderID";
            $resultChiTiet = executeResult($selectChiTietSQL);
            $chitietArray = array();
            foreach($resultChiTiet as $rowChiTiet){
                // Thêm chi tiết đơn hàng vào mảng
                $idsanpham = $rowChiTiet['idsanpham'];
                $sqlSanPham = "select * from sanpham where Id = $idsanpham";
    
                $sanpham = executeSingleResult($sqlSanPham);
                $rowChiTiet['sanpham'] = $sanpham;
                $chitietArray[] = $rowChiTiet;
            }
            
          
            
            // if (mysqli_num_rows($resultChiTiet) > 0) {
            //     while ($rowChiTiet = mysqli_fetch_assoc($resultChiTiet)) {
                  
            //         // Thêm chi tiết đơn hàng vào mảng
            //         $idsanpham = $rowChiTiet['idsanpham'];
            //         $sqlSanPham = "select * from sanpham where Id = $idsanpham";
        
            //         $sanpham = executeSingleResult($sqlSanPham);
            //         $rowChiTiet['sanpham'] = $sanpham;
            //         $chitietArray[] = $rowChiTiet;
            //     }
            // }
          
            // Thêm thông tin đơn hàng và chi tiết vào mảng đơn hàng
            $row['chitiet'] = $chitietArray;
           
            $donhang = array(
                "donhang" => $row,
            );
            $donhangArray[] = $donhang;
        }
    
        // Trả về danh sách đơn hàng đã đặt và chi tiết các đơn hàng đó
        $response = array(
            "result" => 1,
            "message" => "Lây danh sách order thành công",
            "data" => $donhangArray
        );
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
    }
}
