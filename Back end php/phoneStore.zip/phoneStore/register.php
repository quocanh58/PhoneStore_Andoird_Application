<?php
include 'dbhelper.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postdata = file_get_contents("php://input");
    $request = json_decode($postdata);

    if (isset($request->email) && isset($request->password) && isset($request->name) && isset($request->address) && isset($request->phone)) {
        $email = $request->email;
        $password = password_hash($request->password, PASSWORD_BCRYPT);
        $name = $request->name;
        $address = $request->address;
        $phone = $request->phone;

        $sql = "INSERT INTO `user` (`email`, `password`, `name`, `address`, `phone`) VALUES ('$email', '$password', '$name', '$address', '$phone')";

        if (execute($sql)) {
            $response = array(
                "result" => 1,
                "message" => "Register successfully. Please check your email for verification."
            );
            echo json_encode($response);
        } else {
            $response = array(
                "result" => 0,
                "message" => "Đăng ký thất bại"
            );
            echo json_encode($response);
        }
    }
}
?>
